package com.shohruh.macrokeyboard

import android.inputmethodservice.InputMethodService
import android.os.SystemClock
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.ExtractedTextRequest
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

// Eslatma: bu ilovada hech qanday Log chaqiruvi yoʻq — kiritilgan matn (parol maydonlari
// ham) hech qayerga yozilmaydi.
class MacroKeyboardService : InputMethodService() {

    private var adapter: MacroAdapter? = null

    override fun onCreateInputView(): View {
        val view = layoutInflater.inflate(R.layout.keyboard_view, null)

        adapter = MacroAdapter(MacroStore.load(this)) { runMacro(it) }
        view.findViewById<RecyclerView>(R.id.macroList).apply {
            layoutManager = GridLayoutManager(this@MacroKeyboardService, 3)
            adapter = this@MacroKeyboardService.adapter
        }

        view.findViewById<Button>(R.id.btnSwitch).setOnClickListener {
            if (!switchToPreviousInputMethod()) {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showInputMethodPicker()
            }
        }
        return view
    }

    // Tahrirlangan macrolar klaviatura har ochilganda yangilanadi
    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        adapter?.submit(MacroStore.load(this))
    }

    private fun runMacro(m: Macro) {
        val ic = currentInputConnection ?: return
        when {
            m.keyCode != null -> sendKey(ic, m.keyCode, m.meta)
            m.text != null -> insertText(ic, MacroEngine.render(this, m.text))
        }
    }

    private fun insertText(ic: InputConnection, r: MacroEngine.Result) {
        ic.beginBatchEdit()
        ic.commitText(r.text, 1)
        ic.endBatchEdit()

        if (r.back <= 0) return
        val ex = ic.getExtractedText(ExtractedTextRequest(), 0)
        if (ex != null) {
            val pos = ex.startOffset + ex.selectionStart - r.back
            ic.setSelection(pos, pos)
        } else {
            // Zaxira: ayrim ilovalar ExtractedText bermaydi
            repeat(r.back) { sendKey(ic, KeyEvent.KEYCODE_DPAD_LEFT, 0) }
        }
    }

    private fun sendKey(ic: InputConnection, code: Int, meta: Int) {
        val t = SystemClock.uptimeMillis()
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0, meta))
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0, meta))
    }
}
