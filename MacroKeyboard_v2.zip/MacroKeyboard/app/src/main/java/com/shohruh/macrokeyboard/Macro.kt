package com.shohruh.macrokeyboard

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Button
import androidx.recyclerview.widget.RecyclerView

/** text — matn ({sana}, {vaqt}, {clipboard}, {cursor} boʻlishi mumkin); keyCode — tugma hodisasi. */
data class Macro(
    val label: String,
    val text: String? = null,
    val keyCode: Int? = null,
    val meta: Int = 0
)

class MacroAdapter(
    private var items: List<Macro>,
    private val onClick: (Macro) -> Unit
) : RecyclerView.Adapter<MacroAdapter.VH>() {

    class VH(val btn: Button) : RecyclerView.ViewHolder(btn)

    fun submit(newItems: List<Macro>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = VH(
        LayoutInflater.from(parent.context)
            .inflate(R.layout.item_macro, parent, false) as Button
    )

    override fun onBindViewHolder(holder: VH, position: Int) {
        val m = items[position]
        holder.btn.text = m.label
        holder.btn.setOnClickListener { onClick(m) }
    }

    override fun getItemCount() = items.size
}
