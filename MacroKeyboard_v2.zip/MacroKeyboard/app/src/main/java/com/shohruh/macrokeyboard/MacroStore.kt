package com.shohruh.macrokeyboard

import android.content.ClipboardManager
import android.content.Context
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Macrolarni ilovaning ichki papkasida macros.json faylida saqlaydi. */
object MacroStore {
    private const val FILE = "macros.json"

    fun defaults(): List<Macro> = listOf(
        Macro("Salom", text = "Salom! "),
        Macro("gg", text = "gg wp"),
        Macro("/home", text = "/home "),
        Macro("( )", text = "({cursor})"),
        Macro("Sana", text = "{sana}"),
        Macro("Vaqt", text = "{vaqt}"),
        Macro("Paste", text = "{clipboard}"),
        Macro("Enter", keyCode = KeyEvent.KEYCODE_ENTER),
        Macro(
            "Ctrl+C",
            keyCode = KeyEvent.KEYCODE_C,
            meta = KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        )
    )

    fun load(ctx: Context): MutableList<Macro> {
        return try {
            val f = File(ctx.filesDir, FILE)
            if (!f.exists()) return defaults().toMutableList()
            val arr = JSONArray(f.readText())
            MutableList(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Macro(
                    label = o.getString("label"),
                    text = if (o.has("text")) o.getString("text") else null,
                    keyCode = if (o.has("keyCode")) o.getInt("keyCode") else null,
                    meta = o.optInt("meta", 0)
                )
            }
        } catch (e: Exception) {
            defaults().toMutableList()
        }
    }

    fun save(ctx: Context, list: List<Macro>) {
        val arr = JSONArray()
        list.forEach { m ->
            arr.put(JSONObject().apply {
                put("label", m.label)
                m.text?.let { put("text", it) }
                m.keyCode?.let { put("keyCode", it) }
                put("meta", m.meta)
            })
        }
        File(ctx.filesDir, FILE).writeText(arr.toString(2))
    }
}

/** Shablonni yakuniy matnga aylantiradi: {sana}, {vaqt}, {clipboard}, {cursor}. */
object MacroEngine {
    class Result(val text: String, val back: Int)

    private val VAR = Regex("\\{(sana|vaqt|clipboard)\\}")

    fun render(ctx: Context, template: String): Result {
        val i = template.indexOf(CURSOR)
        if (i < 0) return Result(vars(ctx, template), 0)
        val before = vars(ctx, template.substring(0, i))
        val after = vars(ctx, template.substring(i + CURSOR.length).replace(CURSOR, ""))
        return Result(before + after, after.length)
    }

    // Bir oʻtishda almashtiradi: clipboard ichidagi "{vaqt}" kabi matnlar qayta ishlanmaydi.
    private fun vars(ctx: Context, s: String): String = VAR.replace(s) {
        when (it.groupValues[1]) {
            "sana" -> SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date())
            "vaqt" -> SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            else -> clipboard(ctx)
        }
    }

    private fun clipboard(ctx: Context): String {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip ?: return ""
        if (clip.itemCount == 0) return ""
        return clip.getItemAt(0).coerceToText(ctx)?.toString() ?: ""
    }

    private const val CURSOR = "{cursor}"
}
