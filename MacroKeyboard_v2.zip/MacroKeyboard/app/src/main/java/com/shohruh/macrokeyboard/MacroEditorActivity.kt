package com.shohruh.macrokeyboard

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

class MacroEditorActivity : Activity() {

    private lateinit var macros: MutableList<Macro>
    private val rows = mutableListOf<String>()
    private lateinit var listAdapter: ArrayAdapter<String>

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        macros = MacroStore.load(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }

        root.addView(Button(this).apply {
            text = "＋ Macro qoʻshish"
            setOnClickListener { showEditDialog(null) }
        })
        root.addView(Button(this).apply {
            text = "Standartga qaytarish"
            setOnClickListener {
                AlertDialog.Builder(this@MacroEditorActivity)
                    .setMessage("Barcha macrolar standart holatga qaytsinmi?")
                    .setPositiveButton("Ha") { _, _ ->
                        macros = MacroStore.defaults().toMutableList()
                        persist()
                    }
                    .setNegativeButton("Yoʻq", null)
                    .show()
            }
        })
        root.addView(TextView(this).apply {
            text = "Oʻzgaruvchilar: {sana} {vaqt} {clipboard} {cursor}\nTahrirlash — bosing, oʻchirish — uzoq bosing"
            setPadding(0, dp(8), 0, dp(8))
        })

        listAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, rows)
        root.addView(ListView(this).apply {
            adapter = listAdapter
            setOnItemClickListener { _, _, pos, _ -> showEditDialog(pos) }
            setOnItemLongClickListener { _, _, pos, _ ->
                AlertDialog.Builder(this@MacroEditorActivity)
                    .setMessage("“${macros[pos].label}” oʻchirilsinmi?")
                    .setPositiveButton("Oʻchirish") { _, _ ->
                        macros.removeAt(pos)
                        persist()
                    }
                    .setNegativeButton("Bekor", null)
                    .show()
                true
            }
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        setContentView(root)
        refresh()
    }

    private fun refresh() {
        rows.clear()
        macros.forEach { m ->
            val preview = m.text?.replace("\n", "⏎")?.take(30) ?: "[tugma]"
            rows.add("${m.label}  →  $preview")
        }
        listAdapter.notifyDataSetChanged()
    }

    private fun persist() {
        MacroStore.save(this, macros)
        refresh()
    }

    private fun showEditDialog(index: Int?) {
        val old = index?.let { macros[it] }
        val isKey = old?.keyCode != null

        val etLabel = EditText(this).apply {
            hint = "Tugma nomi"
            setSingleLine()
            setText(old?.label ?: "")
        }
        val etText = EditText(this).apply {
            hint = "Matn: {sana} {vaqt} {clipboard} {cursor}"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
            gravity = Gravity.TOP or Gravity.START
            setText(old?.text ?: "")
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), 0)
            addView(etLabel)
            if (!isKey) addView(etText)
        }

        AlertDialog.Builder(this)
            .setTitle(if (old == null) "Yangi macro" else "Tahrirlash")
            .setView(box)
            .setPositiveButton("Saqlash") { _, _ ->
                val label = etLabel.text.toString().trim()
                if (label.isEmpty()) return@setPositiveButton
                val updated = if (old != null && isKey) old.copy(label = label)
                else Macro(label, text = etText.text.toString())
                if (index == null) macros.add(updated) else macros[index] = updated
                persist()
            }
            .setNegativeButton("Bekor", null)
            .show()
    }
}
